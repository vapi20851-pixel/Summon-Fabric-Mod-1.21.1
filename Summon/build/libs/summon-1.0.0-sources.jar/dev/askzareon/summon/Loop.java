package dev.askzareon.summon;

import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.Random;

public final class Loop {
	private static final Random RNG = new Random();
	private static final int TPS = 20;

	public static void tick(MinecraftServer server) {
		for (class_3222 p : server.method_3760().method_14571()) {
			Sessions.Run run = Sessions.get(p.method_5667());
			int tick = server.method_3780();

			if (run.start < 0) {
				run.start = tick;
				run.waveAt = tick + 1200 + RNG.nextInt(2400);
				Books.drop(p, 1);
				run.book1 = true;
				Sessions.save();
			}

			long t = tick - run.start;

			once(p, run, t, 60 * TPS, "hello", "msg.hello", class_124.field_1060, p.method_5477().getString());
			once(p, run, t, 90 * TPS, "world", "msg.world", class_124.field_1060);
			once(p, run, t, 170 * TPS, "why", "msg.why", class_124.field_1060);

			if (!run.waved && tick >= run.waveAt) {
				say(p, "msg.wave", class_124.field_1060, p.method_5477().getString());
				run.waved = true;
				Sessions.save();
			}

			once(p, run, t, 300 * TPS, "guests", "msg.guests", class_124.field_1060);
			once(p, run, t, 360 * TPS, "time", "msg.time", class_124.field_1054);
			once(p, run, t, 420 * TPS, "test", "msg.dont_test", class_124.field_1054);
			once(p, run, t, 480 * TPS, "stay", "msg.overstayed", class_124.field_1054);
			once(p, run, t, 600 * TPS, "leave", "msg.leave", class_124.field_1061);

			if (!run.said("last") && t >= 720 * TPS) {
				say(p, "msg.last_chance", class_124.field_1061);
				run.mark("last");
				finish(p, run);
				Sessions.save();
			}

			if (!run.book2 && t >= 120 * TPS) {
				Books.drop(p, 2);
				run.book2 = true;
				Sessions.save();
			}
			if (!run.book3 && t >= 300 * TPS) {
				Books.drop(p, 3);
				p.method_31548().method_7394(new class_1799(class_1802.field_8477, 3));
				run.book3 = true;
				Sessions.save();
			}
			if (!run.book4 && t >= 600 * TPS) {
				Books.drop(p, 4);
				run.book4 = true;
				Sessions.save();
			}

			if (t >= 360 * TPS) {
				long n = (t - 360 * TPS) / (40 * TPS) + 1;
				if (n > run.punishCount) {
					run.punishCount = n;
					Sessions.save();
					Punish.hit(p);
				}
			}

			if (run.bad) {
				End.spam(p);
			}
		}
	}

	private static void once(class_3222 p, Sessions.Run run, long t, long at, String key, String msg, class_124 c, Object... args) {
		if (t < at || t >= at + TPS || run.said(key)) {
			return;
		}
		say(p, msg, c, args);
		run.mark(key);
		Sessions.save();
	}

	static void say(class_3222 p, String key, class_124 c, Object... args) {
		class_2561 body = class_2561.method_43469(key, args);
		p.method_43496(class_2561.method_43470("[???] ").method_27692(c).method_10852(body.method_27661().method_27692(class_124.field_1068)));
	}

	private static void finish(class_3222 p, Sessions.Run run) {
		if (run.done) {
			return;
		}
		run.done = true;
		if (End.loot(p) > 200) {
			run.canLeave = true;
			State.win();
			State.breakWorld();
			say(p, "msg.entity_leaves", class_124.field_1060);
			say(p, "msg.good_ending", class_124.field_1060);
		} else {
			run.bad = true;
		}
	}
}
