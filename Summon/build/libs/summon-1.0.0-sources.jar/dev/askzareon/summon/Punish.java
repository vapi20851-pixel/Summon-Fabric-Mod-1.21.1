package dev.askzareon.summon;

import java.util.Random;
import net.minecraft.class_1299;
import net.minecraft.class_1538;
import net.minecraft.class_1540;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class Punish {
	private static final Random RNG = new Random();

	public static void hit(class_3222 p) {
		class_3218 lvl = p.method_51469();
		switch (RNG.nextInt(6)) {
			case 0 -> {
				class_2338 pos = p.method_24515().method_10086(8);
				class_1540 f = class_1540.method_40005(lvl, pos, class_2246.field_10535.method_9564());
				if (f != null) {
					f.method_5814(pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5);
				}
			}
			case 1 -> class_1299.field_38095.method_47821(lvl, p.method_24515().method_10069(RNG.nextInt(5) - 2, 0, RNG.nextInt(5) - 2), net.minecraft.class_3730.field_16467);
			case 2 -> {
				class_1299<?>[] m = {class_1299.field_6051, class_1299.field_6137, class_1299.field_6046, class_1299.field_6079, class_1299.field_6091};
				m[RNG.nextInt(m.length)].method_47821(lvl, p.method_24515().method_10069(RNG.nextInt(8) - 4, 0, RNG.nextInt(8) - 4), net.minecraft.class_3730.field_16467);
			}
			case 3 -> {
				class_2338 pos = p.method_24515().method_10069(RNG.nextInt(3) - 1, 0, RNG.nextInt(3) - 1);
				lvl.method_8437(null, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, 3f, net.minecraft.class_1937.class_7867.field_40891);
			}
			case 4 -> {
				class_1538 b = class_1299.field_6112.method_5883(lvl);
				if (b != null) {
					b.method_29495(class_243.method_24955(p.method_24515()));
					lvl.method_8649(b);
				}
			}
			default -> {
				class_2338 c = p.method_24515().method_10074();
				for (int dx = -2; dx <= 2; dx++) {
					for (int dz = -2; dz <= 2; dz++) {
						for (int dy = 0; dy < 3; dy++) {
							lvl.method_8652(c.method_10069(dx, -dy, dz), class_2246.field_10124.method_9564(), 3);
						}
					}
				}
			}
		}
	}
}
