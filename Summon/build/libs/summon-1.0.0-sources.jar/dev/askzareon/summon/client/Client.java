package dev.askzareon.summon.client;

import dev.askzareon.summon.State;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_442;

public class Client implements ClientModInitializer {
	private static boolean showedDead;

	@Override
	public void onInitializeClient() {
		State.load();

		if (State.dead()) {
			ClientTickEvents.END_CLIENT_TICK.register(mc -> {
				if (!showedDead && mc.field_1755 == null) {
					showedDead = true;
					mc.method_1507(new DeadScreen());
				}
			});
			return;
		}

		// TODO: Screens.hook() causes infinite reload loop
		// Screens.hook();

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			if (mc.field_1687 != null) {
				mc.field_1687.method_8435(18000);
			}
			if (mc.field_1755 instanceof class_442) {
				mc.method_1538().method_4859();
			}
		});
	}
}
