package dev.askzareon.summon.client.mixin;

import net.minecraft.class_442;
import net.minecraft.class_8519;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_442.class)
public interface TitleSplashAccessor {
    @Accessor("splash")
    @Mutable
    void summon$setSplash(class_8519 splash);
}
