package dev.askzareon.summon.client;

import dev.askzareon.summon.State;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_442;

public class WarnScreen extends class_437 {
	private final class_437 next;

	public WarnScreen(class_437 next) {
		super(class_2561.method_43471("summon.warning.title"));
		this.next = next;
	}

	@Override
	protected void method_25426() {
		int cx = field_22789 / 2;
		int cy = field_22790 / 2;
		method_37063(class_4185.method_46430(class_2561.method_43471("summon.warning.accept"), b -> {
			State.acceptWarn();
			field_22787.method_1507(next);
		}).method_46434(cx - 100, cy + 60, 200, 20).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43471("summon.warning.cancel"), b -> {
			field_22787.method_1507(new class_442());
		}).method_46434(cx - 100, cy + 90, 200, 20).method_46431());
	}

	@Override
	public void method_25394(class_332 g, int mx, int my, float d) {
		method_25420(g, mx, my, d);
		g.method_27534(field_22793, field_22785, field_22789 / 2, field_22790 / 2 - 60, 0xFF5555);
		g.method_27534(field_22793, class_2561.method_43471("summon.warning.line1"), field_22789 / 2, field_22790 / 2 - 30, 0xFFFFFF);
		g.method_27534(field_22793, class_2561.method_43471("summon.warning.line2"), field_22789 / 2, field_22790 / 2 - 15, 0xFFFFFF);
		g.method_27534(field_22793, class_2561.method_43471("summon.warning.line3"), field_22789 / 2, field_22790 / 2, 0xAAAAAA);
		g.method_27534(field_22793, class_2561.method_43471("summon.warning.wip"), field_22789 / 2, field_22790 / 2 + 18, 0x888888);
		super.method_25394(g, mx, my, d);
	}

	@Override
	public boolean method_25422() {
		return false;
	}
}
