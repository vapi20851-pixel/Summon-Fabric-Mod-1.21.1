package dev.askzareon.summon.client.mixin;

import net.minecraft.class_364;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_437.class)
public interface ScreenAddWidgetAccessor {
    @Invoker("addRenderableWidget")
    <T extends class_364> T summon$addRenderableWidget(T widget);
}
