package dev.askzareon.summon.client;

import dev.askzareon.summon.Sessions;
import dev.askzareon.summon.State;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.class_2561;
import net.minecraft.class_408;
import net.minecraft.class_429;
import net.minecraft.class_433;
import net.minecraft.class_442;
import net.minecraft.class_525;
import net.minecraft.class_526;

public final class Screens {
	private Screens() {
	}

	public static void hook() {
		ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
			if (State.dead()) {
				return;
			}

			if (State.worldGone() && screen instanceof class_526) {
				client.method_1507(new class_442());
				client.field_1705.method_1758(class_2561.method_43471("summon.world.corrupted"), false);
				return;
			}

			if (screen instanceof class_525) {
				client.method_1507(new class_526(new class_442()));
				return;
			}

			if (screen instanceof class_408) {
				client.method_1507(null);
				return;
			}

			if (screen instanceof class_442 title) {
				Ui.hide(title,
						class_2561.method_43471("menu.online"),
						class_2561.method_43471("menu.quit"),
						class_2561.method_43471("options.accessibility"));
			} else if (screen instanceof class_433 pause) {
				Ui.hideLike(pause, "disconnect", "report", "bug", "advancement", "statistic", "feedback",
						"отзыв", "ошибк", "достижен", "статистик", "выйти");
				if (client.field_1724 != null && !Sessions.get(client.field_1724.method_5667()).canLeave) {
					Ui.hideLike(pause, "disconnect", "выйти", "title");
				}
			} else if (screen instanceof class_429 opts) {
				Ui.hideLike(opts,
						"skin", "appearance", "music", "video", "controls", "chat", "resource", "accessibility",
						"telemetry", "data", "attribute", "внешн", "музык", "график", "управлен", "чат", "ресурс",
						"специальн", "телеметр", "данн", "атрибут");
			} else if (screen instanceof class_526 select) {
				Ui.hideLike(select, "create", "delete", "edit", "recreate");
			}
		});
	}
}
