package dev.askzareon.summon.client.mixin;

import dev.askzareon.summon.State;
import net.minecraft.class_332;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_442.class)
public class ScreenRenderMixin {
    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true)
    private void summon$bg(class_332 g, int mx, int my, float d, CallbackInfo ci) {
        if (!State.dead()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderPanorama", at = @At("HEAD"), cancellable = true)
    private void summon$pan(class_332 g, float d, CallbackInfo ci) {
        if (!State.dead()) {
            ci.cancel();
        }
    }
}
