package dev.askzareon.summon.client;

import net.minecraft.class_2561;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class Ui {
	public static void hide(class_437 s, class_2561... labels) {
		for (class_364 w : s.method_25396()) {
			if (w instanceof class_4185 b) {
				for (class_2561 l : labels) {
					if (b.method_25369().getString().equals(l.getString())) {
						b.field_22764 = false;
						b.field_22763 = false;
					}
				}
			}
		}
	}

	public static void hideLike(class_437 s, String... bits) {
		for (class_364 w : s.method_25396()) {
			if (w instanceof class_4185 b) {
				String t = b.method_25369().getString().toLowerCase();
				for (String bit : bits) {
					if (t.contains(bit.toLowerCase())) {
						b.field_22764 = false;
						b.field_22763 = false;
					}
				}
			}
		}
	}
}
