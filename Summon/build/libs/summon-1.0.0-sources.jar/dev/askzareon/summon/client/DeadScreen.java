package dev.askzareon.summon.client;

import dev.askzareon.summon.State;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class DeadScreen extends class_437 {
	public DeadScreen() {
		super(class_2561.method_43470(State.brokenName()));
	}

	@Override
	public void method_25394(class_332 g, int mx, int my, float d) {
		method_25420(g, mx, my, d);
		g.method_25300(field_22793, State.brokenName(), field_22789 / 2, field_22790 / 2 - 20, 0xFF0000);
		g.method_25300(field_22793, State.brokenDesc(), field_22789 / 2, field_22790 / 2, 0x888888);
		g.method_27534(field_22793, class_2561.method_43469("summon.broken.author", "askzAreon"), field_22789 / 2, field_22790 / 2 + 20, 0x555555);
	}

	@Override
	public boolean method_25422() {
		return false;
	}
}
