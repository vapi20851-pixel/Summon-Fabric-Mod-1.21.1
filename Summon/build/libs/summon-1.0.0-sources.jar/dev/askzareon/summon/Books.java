package dev.askzareon.summon;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_9262;
import net.minecraft.class_9302;
import net.minecraft.class_9334;

public final class Books {
	public static void drop(class_3222 p, int n) {
		switch (n) {
			case 1 -> give(p, "book.first.title", "book.first.page1");
			case 2 -> give(p, "book.second.title", "book.second.page1");
			case 3 -> give(p, "book.third.title", "book.third.page1");
			case 4 -> give(p, "book.fourth.title", "book.fourth.page1");
		}
	}

	private static void give(class_3222 p, String title, String page) {
		class_1799 book = new class_1799(class_1802.field_8360);
		book.method_57379(class_9334.field_49606, new class_9302(
				class_9262.method_57137(class_2561.method_43471(title).getString()),
				"?",
				0,
				List.of(class_9262.method_57137(class_2561.method_43471(page))),
				true
		));
		p.method_31548().method_7394(book);
	}
}
