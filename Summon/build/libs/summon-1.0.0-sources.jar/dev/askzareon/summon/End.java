package dev.askzareon.summon;

import java.util.Random;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public final class End {
	private static final Random RNG = new Random();
	private static final String GARBAGE = "!@#$%^&*()_+-=[]{}|;':\",./<>?~`\\";

	public static int loot(class_3222 p) {
		int n = 0;
		for (int i = 0; i < p.method_31548().method_5439(); i++) {
			class_1799 s = p.method_31548().method_5438(i);
			if (s.method_7960()) {
				continue;
			}
			int v = 0;
			if (s.method_31574(class_1802.field_8620)) v = 1;
			else if (s.method_31574(class_1802.field_8695)) v = 2;
			else if (s.method_31574(class_1802.field_8477)) v = 5;
			else if (s.method_31574(class_1802.field_22021)) v = 10;
			else if (s.method_31574(class_1802.field_22020)) v = 20;
			n += v * s.method_7947();
		}
		return n;
	}

	public static void spam(class_3222 p) {
		Sessions.Run run = Sessions.get(p.method_5667());
		if (!run.bad || run.canLeave) {
			return;
		}
		if (p.method_5682().method_3780() % 20 != 0) {
			return;
		}

		run.spam++;
		var sb = new StringBuilder();
		for (int i = 0; i < 80; i++) {
			sb.append(GARBAGE.charAt(RNG.nextInt(GARBAGE.length())));
		}

		p.method_43496(class_2561.method_43470("[???] ").method_27692(class_124.field_1079)
				.method_10852(class_2561.method_43470(sb.toString()).method_27692(class_124.field_1079)));

		if (run.spam >= 20) {
			State.kill();
			p.field_13987.method_52396(class_2561.method_43470("..."));
			throw new RuntimeException("no");
		}
		Sessions.save();
	}
}
