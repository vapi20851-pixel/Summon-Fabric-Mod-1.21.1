package dev.askzareon.summon;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_7923;

public final class World {
	private static final Random RNG = new Random();
	private static boolean done;

	public static void scramble(class_3218 lvl) {
		if (State.worldGone() || done) {
			return;
		}
		done = true;

		List<class_2248> blocks = new ArrayList<>();
		for (class_2248 b : class_7923.field_41175) {
			if (b != class_2246.field_10124 && b != class_2246.field_10243 && b != class_2246.field_10543) {
				blocks.add(b);
			}
		}

		class_2338 c = lvl.method_43126();
		int r = 64;
		for (int x = -r; x <= r; x++) {
			for (int z = -r; z <= r; z++) {
				for (int y = lvl.method_31607(); y < lvl.method_31600(); y++) {
					lvl.method_8652(c.method_10069(x, y, z), blocks.get(RNG.nextInt(blocks.size())).method_9564(), 2);
				}
			}
		}
		lvl.method_29199(18000);
	}
}
