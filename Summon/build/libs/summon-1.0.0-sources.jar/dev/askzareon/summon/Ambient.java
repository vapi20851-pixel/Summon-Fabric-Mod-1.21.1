package dev.askzareon.summon;

import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2621;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.Random;

public final class Ambient {
	private static final Random RNG = new Random();
	private static int wait;

	public static void tick(MinecraftServer server) {
		if (++wait % 600 != 0) {
			return;
		}
		class_3218 lvl = server.method_30002();
		if (lvl == null) {
			return;
		}
		List<class_3222> ps = server.method_3760().method_14571();
		if (ps.isEmpty()) {
			return;
		}
		class_3222 p = ps.get(RNG.nextInt(ps.size()));
		switch (RNG.nextInt(3)) {
			case 0 -> chest(lvl, p);
			case 1 -> rain(lvl, p);
			default -> hurt(p);
		}
	}

	private static void chest(class_3218 lvl, class_3222 p) {
		class_2338 pos = lvl.method_8598(net.minecraft.class_2902.class_2903.field_13202,
				p.method_24515().method_10069(RNG.nextInt(20) - 10, 0, RNG.nextInt(20) - 10));
		lvl.method_8652(pos, class_2246.field_10034.method_9564(), 3);
		class_2586 be = lvl.method_8321(pos);
		if (be instanceof class_2621 c) {
			if (RNG.nextBoolean()) {
				c.method_5447(0, new class_1799(class_1802.field_8635, 16));
				c.method_5447(1, new class_1799(class_1802.field_8626, 2));
			} else {
				c.method_5447(0, new class_1799(class_1802.field_8620, RNG.nextInt(8) + 1));
				c.method_5447(1, new class_1799(class_1802.field_8695, RNG.nextInt(4) + 1));
			}
		}
	}

	private static void rain(class_3218 lvl, class_3222 p) {
		if (RNG.nextBoolean()) {
			for (int i = 0; i < 30; i++) {
				class_1799 s = RNG.nextBoolean() ? new class_1799(class_1802.field_8567) : new class_1799(class_1802.field_8429);
				lvl.method_8649(new class_1542(lvl, p.method_23317() + RNG.nextInt(10) - 5, p.method_23318() + 10, p.method_23321() + RNG.nextInt(10) - 5, s));
			}
		} else {
			for (int i = 0; i < 5; i++) {
				class_1299.field_6062.method_47821(lvl, p.method_24515().method_10069(RNG.nextInt(10) - 5, 1, RNG.nextInt(10) - 5), net.minecraft.class_3730.field_16467);
			}
		}
	}

	private static void hurt(class_3222 p) {
		class_6880<class_1291>[] fx = new class_6880[]{
				class_1294.field_38092, class_1294.field_5919, class_1294.field_5920,
				class_1294.field_5909, class_1294.field_5911
		};
		p.method_6092(new class_1293(fx[RNG.nextInt(fx.length)], 100 + RNG.nextInt(200), RNG.nextInt(2)));
	}
}
